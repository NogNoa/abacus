# a relatively simple abacus emulation
